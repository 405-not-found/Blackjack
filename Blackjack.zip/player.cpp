#include "player.h"

// SimplePlayer class
class SimplePlayer : public Player
{
public:
    int bet(unsigned int bankroll, unsigned int minimum) override
    {
        return minimum; // Always place the minimum bet
    }

    bool draw(Card dealer, const Hand &player) override
    {
        HandValue handValue = player.handValue();

        if (!handValue.soft)
        {
            // Hard count rules
            if (handValue.count <= 11)
            {
                return true; // Hit if total is 11 or less
            }
            else if (handValue.count == 12)
            {
                // Stand if dealer shows 4, 5, or 6; otherwise hit
                bool hitval=(dealer.spot == FOUR || dealer.spot == FIVE || dealer.spot == SIX);
                return !hitval;
            }
            else if (handValue.count >= 13 && handValue.count <= 16)
            {
                // Stand if dealer shows 2 through 6; otherwise hit
                bool hitval=(dealer.spot >= TWO && dealer.spot <= SIX);
                return !hitval;
            }
            return false;
        }
        else
        {
            // Soft count rules
            if (handValue.count <= 17)
            {
                return true; // Hit if total is 17 or less
            }
            else if (handValue.count == 18)
            {
                // Stand if dealer shows 2, 7, or 8; otherwise hit
                return !(dealer.spot == TWO || dealer.spot == SEVEN || dealer.spot == EIGHT);
            }
        }

        return false; // Stand for all other cases
    }

    void expose(Card c) override
    {
        // Do nothing
    }

    void shuffled() override
    {
        // Do nothing
    }
};

// CountingPlayer class
class CountingPlayer : public SimplePlayer
{
    int count; // Running count of the cards seen

public:
    CountingPlayer() : count(0) {}

    int bet(unsigned int bankroll, unsigned int minimum) override
    {
        if (count >= 2 && bankroll >= minimum * 2)
        {
            return minimum * 2; // Bet double the minimum if count is +2 or greater
        }
        else
        {
            return minimum; // Bet the minimum for all other cases
        }
    }

    void expose(Card c) override
    {
        if (c.spot >= TEN && c.spot <= ACE)
        {
            count--; // Subtract 1 from the count for face cards and Aces
        }
        else if (c.spot >= TWO && c.spot <= SIX)
        {
            count++; // Add 1 to the count for low-numbered cards
        }
    }

    void shuffled() override
    {
        count = 0; // Reset the count to zero when the deck is shuffled
    }
};

// Static instances of SimplePlayer and CountingPlayer
static SimplePlayer simplePlayer;
static CountingPlayer countingPlayer;

// Access functions
extern Player *get_Simple()
{
    return &simplePlayer;
}

extern Player *get_Counting()
{
    return &countingPlayer;
}

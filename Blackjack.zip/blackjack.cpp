#include <string>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cassert>
#include "deck.h"
#include "card.h"
#include "hand.h"
#include "player.h"
#include "rand.h"

using namespace std;

int main(int argc, char *argv[])
{
    // Initial variables

    int bankroll = atoi(argv[1]);
    int hands = atoi(argv[2]);
    int thishand = 1;
    string player_type = argv[3];
    Deck mydeck;
    Player *myplayer;
    Hand dealerhand, playerhand;
    Card dealerfaceup;
    Card dealertime;
    Card dealerholecard;

    // Create Player according to the player type
    if (player_type == "simple")
    {
        myplayer = get_Simple();
    }
    else
    {
        myplayer = get_Counting();
    }

    // Shuffle the deck 7 times
    cout << "Shuffling the deck\n";
    for (int i = 0; i <= 6; i++)
    {
        int cutnumber = get_cut();
        cout << "cut at " << cutnumber << endl;
        mydeck.shuffle(cutnumber);
    }

    myplayer->shuffled();

    if (bankroll < 5)
    {
        cout << "Player has " << bankroll
             << " after "
             << "0"
             << " hands\n";
    }
    else
    {

        while (bankroll >= 5 && hands - thishand >= 0)
        {
            // Announce the hand
            cout << "Hand " << thishand << " bankroll " << bankroll << endl;
            thishand++;

            // If there are fewer than 20 cards left, reshuffle the deck

            if (mydeck.cardsLeft() < 20)
            {
                cout << "Shuffling the deck\n";
                for (int i = 0; i <= 6; i++)
                {
                    int cutnumber = get_cut();
                    mydeck.shuffle(cutnumber);
                    cout << "cut at " << cutnumber << endl;
                }
                myplayer->shuffled();
            }

            // Ask the player for a wager and announce it
            int minimum = 5;
            int wager = myplayer->bet(bankroll, minimum);
            cout << "Player bets " << wager << endl;

            // Deal four cards
            for (int i = 0; i <= 3; i++)
            {
                Card dealcard = mydeck.deal();
                if (i == 0 || i == 2)
                {
                    myplayer->expose(dealcard);
                    playerhand.addCard(dealcard);
                    cout << "Player dealt " << SpotNames[dealcard.spot] << " of " << SuitNames[dealcard.suit] << endl;
                }
                if (i == 1)
                {
                    dealerfaceup = dealcard;
                    myplayer->expose(dealcard);
                    dealerhand.addCard(dealcard);
                    cout << "Dealer dealt " << SpotNames[dealcard.spot] << " of " << SuitNames[dealcard.suit] << endl;
                }
                if (i == 3)
                {
                    dealerholecard=dealcard;
                    dealerhand.addCard(dealcard);
                }
            }

            // Natural 21 situation
            if (playerhand.handValue().count == 21)
            {
                int payment = (3 * wager) / 2;
                bankroll = bankroll + payment;
                cout << "Player dealt natural 21\n";
            }

            // Play his hand
            while (myplayer->draw(dealerfaceup, playerhand) && playerhand.handValue().count < 21)
            {
                Card drawcard = mydeck.deal();
                playerhand.addCard(drawcard);
                cout << "Player dealt " << SpotNames[drawcard.spot] << " of " << SuitNames[drawcard.suit] << endl;
                myplayer->expose(drawcard);
            }
            // Announce the player's total
            cout << "Player's total is " << playerhand.handValue().count << endl;

            // If bust
            if (playerhand.handValue().count > 21)
            {
                cout << "Player busts\n";
                bankroll = bankroll - wager;
            }
            else
            {
                cout << "Dealer's hole card is " << SpotNames[dealerholecard.spot] << " of " << SuitNames[dealerholecard.suit]<<endl;
                myplayer->expose(dealerfaceup);
            }

            // Play dealerhand
            while (dealerhand.handValue().count < 17 && playerhand.handValue().count <21)
            {
                dealertime = mydeck.deal();
                cout << "Dealer dealt " << SpotNames[dealertime.spot] << " of " << SuitNames[dealertime.suit] << endl;
                dealerhand.addCard(dealertime);
                myplayer->expose(dealertime);
            }

            // Announce the dealer's total
            cout << "Dealer's total is " << dealerhand.handValue().count << endl;

            // If bust
            if (dealerhand.handValue().count > 21 && playerhand.handValue().count <21)
            {
                cout << "Dealer busts\n";
                bankroll = bankroll + wager;
            }
            else
            {
                if (playerhand.handValue().count > dealerhand.handValue().count && playerhand.handValue().count <21)
                {
                    cout << "Player wins\n";
                    bankroll = bankroll + wager;
                }
                if (playerhand.handValue().count == dealerhand.handValue().count && playerhand.handValue().count <21)
                {
                    cout << "Push\n";
                }
                if (playerhand.handValue().count < dealerhand.handValue().count && playerhand.handValue().count <21)
                {
                    cout << "Dealer wins\n";
                    bankroll = bankroll - wager;
                }
            }
            playerhand.discardAll();
            dealerhand.discardAll();
        }
    }
    cout << "Player has " << bankroll << " after " << thishand-1 << " hands\n";
}
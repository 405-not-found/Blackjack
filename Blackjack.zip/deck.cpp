#include "deck.h"

Deck::Deck()
{
    reset();
}

void Deck::reset()
{
    next = 0;
    int cardIndex = 0;

    for (int suit = SPADES; suit <= DIAMONDS; ++suit)
    {
        for (int spot = TWO; spot <= ACE; ++spot)
        {
            deck[cardIndex].spot = static_cast<Spot>(spot);
            deck[cardIndex].suit = static_cast<Suit>(suit);
            ++cardIndex;
        }
    }
}

void Deck::shuffle(int n)
{
    // Cut the deck in two segments
    Card left[n];
    Card right[DeckSize - n];
    for (int i = 0; i < n; i++)
    {
        left[i] = deck[i];
    }

    for (int i = n; i < DeckSize; i++)
    {
        right[i - n] = deck[i];
    }

    // Rearrange the deck
    int leftIndex = 0;
    int rightIndex = 0;
    int currentIndex = 0;
    while (leftIndex < n && rightIndex < DeckSize - n)
    {
        deck[currentIndex++] = right[rightIndex++];
        deck[currentIndex++] = left[leftIndex++];
    }

    while (leftIndex < n)
    {
        deck[currentIndex++] = left[leftIndex++];
    }

    while (rightIndex < DeckSize - n)
    {
        deck[currentIndex++] = right[rightIndex++];
    }
    // Initialize to be the first card to deal with
    next = 0;
}

Card Deck::deal()
{
    if (next >= DeckSize)
    {
        throw DeckEmpty(); // No cards remaining in the deck
    }

    Card card = deck[next];
    next++; // Move to the next card

    return card;
}


int Deck::cardsLeft()
{
    return DeckSize - next;
}
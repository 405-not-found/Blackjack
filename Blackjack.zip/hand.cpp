#include "hand.h"

Hand::Hand()
{
    discardAll();
}

void Hand::discardAll()
{
    curValue.count = 0;
    curValue.soft = false;
}

void Hand::addCard(Card c)
{
    int cardValue = static_cast<int>(c.spot) + 2; // Convert Spot enum to card value
    if (cardValue > 10)
    {
        cardValue = 10; // Face cards (J, Q, K) have a value of 10
    }

    if (c.spot == ACE)
    {
        // Check if adding an Ace will make the hand value go over 21
        if (curValue.count + 11 > 21)
        {
            cardValue = 1; // If so, count the Ace as 1
        }
        else
        {
            cardValue = 11;       // Otherwise, count the Ace as 11
            curValue.soft = true; // Set the soft flag to true
        }
    }
    else if (curValue.soft && curValue.count + cardValue > 21)
    {
        // If the hand has a soft ACE and adding the current card value
        // exceeds 21, adjust the ACE value from 11 to 1
        curValue.count -= 10; // Subtract 10 to change the ACE value from 11 to 1
        curValue.soft = false; // Set the soft flag to false
    }

    curValue.count += cardValue; // Add the card value to the hand count
}


HandValue Hand::handValue() const
{
    return curValue;
}
